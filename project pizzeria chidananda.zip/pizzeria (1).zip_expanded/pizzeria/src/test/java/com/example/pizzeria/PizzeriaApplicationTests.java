package com.example.pizzeria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PizzeriaApplicationTests {

	@Test
	void contextLoads() {
	}

}
