package com.example.pizzeria.dto;

import lombok.*;
import java.util.List;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class OrderDto {
    private Long orderId;
    private Long userId;
    private List<OrderItemDto> items;
    private Double totalAmount;
    private String status;       // PLACED, ACCEPTED, etc.
    private String deliveryMode; // DELIVERY, TAKEAWAY
}
