package com.example.pizzeria.entity;


import jakarta.persistence.*;
import lombok.*;
import java.time.*;
import java.util.*;


@Entity @Table(name = "orders")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Order {
@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;


@ManyToOne(optional=false)
private User user;


@OneToMany(mappedBy = "order", cascade = CascadeType.ALL, orphanRemoval = true)
private List<OrderItem> items = new ArrayList<>();


@Enumerated(EnumType.STRING)
private OrderStatus status;


@Enumerated(EnumType.STRING)
private DeliveryMode deliveryMode;


private LocalDateTime createdAt;
}