package com.example.pizzeria.entity;


import jakarta.persistence.*;
import lombok.*;


@Entity

public class Payment {
@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;


@OneToOne(optional=false)
private Order order;


@Enumerated(EnumType.STRING)
private PaymentMethod method;


@Enumerated(EnumType.STRING)
private PaymentStatus status;
}