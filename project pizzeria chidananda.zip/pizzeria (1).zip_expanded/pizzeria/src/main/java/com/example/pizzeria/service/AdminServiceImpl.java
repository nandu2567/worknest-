package com.example.pizzeria.service;

import com.example.pizzeria.dto.BillDto;
import com.example.pizzeria.entity.*;
import com.example.pizzeria.repository.*;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.util.List;

@Service
public class AdminServiceImpl implements AdminService {

    private final MenuItemRepository menuItemRepo;
    private final OrderRepository orderRepo;
    private final BillRepository billRepo;

    public AdminServiceImpl(MenuItemRepository menuItemRepo,
                            OrderRepository orderRepo,
                            BillRepository billRepo) {
        this.menuItemRepo = menuItemRepo;
        this.orderRepo = orderRepo;
        this.billRepo = billRepo;
    }

    @Override
    public MenuItem addMenuItem(MenuItem item) {
        return menuItemRepo.save(item);
    }

    @Override
    public List<MenuItem> getMenuItems() {
        return menuItemRepo.findAll();
    }

    @Override
    public MenuItem updateMenuItem(Long id, MenuItem item) {
        MenuItem existing = menuItemRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Menu item not found"));
        existing.setName(item.getName());
        existing.setDescription(item.getDescription());
        existing.setPrice(item.getPrice());
        existing.setCategory(item.getCategory());
        return menuItemRepo.save(existing);
    }

    @Override
    public void deleteMenuItem(Long id) {
        menuItemRepo.deleteById(id);
    }

    @Override
    public void acceptOrder(Long orderId) {
        Order order = orderRepo.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));
        order.setStatus(OrderStatus.ACCEPTED);
        orderRepo.save(order);
    }

    @Override
    public void rejectOrder(Long orderId) {
        Order order = orderRepo.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));
        order.setStatus(OrderStatus.REJECTED);
        orderRepo.save(order);
    }

    @Override
    public BillDto generateBill(Long orderId) {
        Order order = orderRepo.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));

        BigDecimal subtotal = order.getItems().stream()
                .map(i -> i.getPriceAtOrder().multiply(BigDecimal.valueOf(i.getQuantity())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal tax = subtotal.multiply(new BigDecimal("0.05")); // 5% tax
        BigDecimal total = subtotal.add(tax);

        Bill bill = Bill.builder()
                .order(order)
                .subtotal(subtotal)
                .tax(tax)
                .totalAmount(total)
                .createdAt(LocalDateTime.now())
                .build();
        billRepo.save(bill);

        return new BillDto(bill.getId(), orderId, subtotal, tax, total, bill.getCreatedAt());
    }

    @Override
    public BigDecimal calculateMonthlyRevenue() {
        YearMonth currentMonth = YearMonth.now();
        LocalDateTime start = currentMonth.atDay(1).atStartOfDay();
        LocalDateTime end = currentMonth.atEndOfMonth().atTime(23, 59, 59);

        List<Bill> bills = billRepo.findByCreatedAtBetween(start, end);
        return bills.stream()
                .map(Bill::getTotalAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
}
