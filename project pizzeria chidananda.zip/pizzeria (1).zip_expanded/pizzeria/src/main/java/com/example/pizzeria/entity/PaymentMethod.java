package com.example.pizzeria.entity;

public enum PaymentMethod { UPI, CARD, COD }