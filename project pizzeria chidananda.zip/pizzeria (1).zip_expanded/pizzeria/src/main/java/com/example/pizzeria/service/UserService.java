package com.example.pizzeria.service;

import com.example.pizzeria.dto.OrderDto;
import com.example.pizzeria.dto.PaymentDto;
import com.example.pizzeria.entity.MenuItem;

import java.util.List;

public interface UserService {
    List<MenuItem> getMenu();
    OrderDto placeOrder(OrderDto orderDto);
    void cancelOrder(Long orderId);
    String getOrderStatus(Long orderId);
    void makePayment(PaymentDto paymentDto);
}
