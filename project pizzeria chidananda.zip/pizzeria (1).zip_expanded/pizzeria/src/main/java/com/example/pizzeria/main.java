package com.example.pizzeria;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class main {
    private static final String URL = "jdbc:mysql://localhost:3306/pizzeria?useSSL=false&serverTimezone=UTC";
    private static final String USER = "root";        // your MySQL username
    private static final String PASSWORD = "Nandu"; // your MySQL password

    public static Connection getConnection() {
        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connect to database
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Connected to database successfully!");
            return conn;
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL Driver not found.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Connection failed.");
            e.printStackTrace();
        }
        return null;
    }

    public main(String[] args) {
        getConnection();
    }
}
