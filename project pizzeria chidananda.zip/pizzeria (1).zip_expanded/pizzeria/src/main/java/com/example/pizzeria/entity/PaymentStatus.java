package com.example.pizzeria.entity;

public enum PaymentStatus { PENDING, SUCCESS, FAILED }