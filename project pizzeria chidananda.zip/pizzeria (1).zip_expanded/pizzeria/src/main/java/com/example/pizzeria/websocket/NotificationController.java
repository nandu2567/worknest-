package com.example.pizzeria.websocket;

import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;

@Controller
public class NotificationController {

    @MessageMapping("/orderStatus")   // client sends to /app/orderStatus
    @SendTo("/topic/status")          // broadcast to subscribers
    public String sendStatusUpdate(String message) {
        return message;
    }
}
