package com.example.pizzeria.dto;


import lombok.*;
import jakarta.validation.constraints.*;


public class AuthDtos {
@Getter @Setter
public static class RegisterRequest {
@Email @NotBlank private String email;
@NotBlank private String password;
@NotBlank private String name;
}


@Getter @Setter
public static class LoginRequest {
@Email @NotBlank private String email;
@NotBlank private String password;
}


@Getter @Setter @AllArgsConstructor
public static class AuthResponse {
private String token;
private String role;
private String name;
}
}