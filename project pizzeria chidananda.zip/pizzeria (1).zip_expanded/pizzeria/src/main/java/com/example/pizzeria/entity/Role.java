package com.example.pizzeria.entity;

public enum Role { ADMIN, CUSTOMER }
