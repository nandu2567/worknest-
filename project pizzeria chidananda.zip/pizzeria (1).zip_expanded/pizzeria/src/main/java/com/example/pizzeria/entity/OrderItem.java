package com.example.pizzeria.entity;


import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;


@Entity
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class OrderItem {
@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;


@ManyToOne(optional=false)
private Order order;


@ManyToOne(optional=false)
private MenuItem menuItem;


private int quantity;
private BigDecimal priceAtOrder; // snapshot
}