package com.example.pizzeria.dto;


import com.example.pizzeria.entity.Category;
import lombok.*;
import java.math.BigDecimal;


@Getter @Setter
public class MenuItemDto {
private Long id;
private String name;
private String description;
private BigDecimal price;
private Category category;
}