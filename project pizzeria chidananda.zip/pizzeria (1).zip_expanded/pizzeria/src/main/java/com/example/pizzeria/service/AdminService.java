package com.example.pizzeria.service;

import com.example.pizzeria.dto.BillDto;
import com.example.pizzeria.entity.MenuItem;

import java.math.BigDecimal;
import java.util.List;

public interface AdminService {
    MenuItem addMenuItem(MenuItem item);
    List<MenuItem> getMenuItems();
    MenuItem updateMenuItem(Long id, MenuItem item);
    void deleteMenuItem(Long id);

    void acceptOrder(Long orderId);
    void rejectOrder(Long orderId);

    BillDto generateBill(Long orderId);
    BigDecimal calculateMonthlyRevenue();
}
