package com.example.pizzeria.controller;

import com.example.pizzeria.dto.BillDto;
import com.example.pizzeria.entity.MenuItem;
import com.example.pizzeria.service.AdminService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    private final AdminService adminService;

    public AdminController(AdminService adminService) {
        this.adminService = adminService;
    }

    // CRUD on Menu Items
    @PostMapping("/menu")
    public ResponseEntity<MenuItem> addMenuItem(@RequestBody MenuItem item) {
        return ResponseEntity.ok(adminService.addMenuItem(item));
    }

    @GetMapping("/menu")
    public ResponseEntity<List<MenuItem>> getMenuItems() {
        return ResponseEntity.ok(adminService.getMenuItems());
    }

    @PutMapping("/menu/{id}")
    public ResponseEntity<MenuItem> updateMenuItem(@PathVariable Long id, @RequestBody MenuItem item) {
        return ResponseEntity.ok(adminService.updateMenuItem(id, item));
    }

    @DeleteMapping("/menu/{id}")
    public ResponseEntity<String> deleteMenuItem(@PathVariable Long id) {
        adminService.deleteMenuItem(id);
        return ResponseEntity.ok("Item deleted");
    }

    // Orders management
    @PostMapping("/orders/{orderId}/accept")
    public ResponseEntity<String> acceptOrder(@PathVariable Long orderId) {
        adminService.acceptOrder(orderId);
        return ResponseEntity.ok("Order accepted");
    }

    @PostMapping("/orders/{orderId}/reject")
    public ResponseEntity<String> rejectOrder(@PathVariable Long orderId) {
        adminService.rejectOrder(orderId);
        return ResponseEntity.ok("Order rejected");
    }

    // Billing
    @GetMapping("/bill/{orderId}")
    public ResponseEntity<BillDto> generateBill(@PathVariable Long orderId) {
        return ResponseEntity.ok(adminService.generateBill(orderId));
    }

    // Revenue
    @GetMapping("/revenue")
    public ResponseEntity<BigDecimal> getMonthlyRevenue() {
        return ResponseEntity.ok(adminService.calculateMonthlyRevenue());
    }
}
