package com.example.pizzeria.controller;

import com.example.pizzeria.dto.OrderDto;
import com.example.pizzeria.dto.PaymentDto;
import com.example.pizzeria.entity.MenuItem;
import com.example.pizzeria.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/user")
public class UserController {

    private final UserService userService;
    public UserController(UserService userService) {
        this.userService = userService;
    }

    // Browse menu
    @GetMapping("/menu")
    public ResponseEntity<List<MenuItem>> getMenu() {
        return ResponseEntity.ok(userService.getMenu());
    }

    // Place order
    @PostMapping("/orders")
    public ResponseEntity<OrderDto> placeOrder(@RequestBody OrderDto orderDto) {
        return ResponseEntity.ok(userService.placeOrder(orderDto));
    }

    // Cancel order
    @PostMapping("/orders/{orderId}/cancel")
    public ResponseEntity<String> cancelOrder(@PathVariable Long orderId) {
        userService.cancelOrder(orderId);
        return ResponseEntity.ok("Order cancelled");
    }

    // Get order status
    @GetMapping("/orders/{orderId}/status")
    public ResponseEntity<String> getOrderStatus(@PathVariable Long orderId) {
        return ResponseEntity.ok(userService.getOrderStatus(orderId));
    }

    // Payment
    @PostMapping("/payment")
    public ResponseEntity<String> makePayment(@RequestBody PaymentDto paymentDto) {
        userService.makePayment(paymentDto);
        return ResponseEntity.ok("Payment processed successfully");
    }
}
