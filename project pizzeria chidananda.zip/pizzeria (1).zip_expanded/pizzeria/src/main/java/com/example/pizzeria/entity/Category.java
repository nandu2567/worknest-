package com.example.pizzeria.entity;

public enum Category { PIZZA, SIDES, BEVERAGES, COMBO, NEW_LAUNCH, BESTSELLER }


