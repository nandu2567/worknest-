package com.example.pizzeria.entity;


import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.*;


@Entity

public class Bill {
@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;


@OneToOne(optional=false)
private Order order;


private BigDecimal subtotal;
private BigDecimal tax;
private BigDecimal totalAmount;
private LocalDateTime createdAt;
}