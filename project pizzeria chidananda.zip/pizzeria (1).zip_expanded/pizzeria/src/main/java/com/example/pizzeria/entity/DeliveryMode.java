package com.example.pizzeria.entity;

public enum DeliveryMode { TAKEAWAY, DELIVERY }


