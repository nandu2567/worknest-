package com.example.pizzeria.entity;

public enum OrderStatus {
  PLACED, ACCEPTED, REJECTED, PREPARING, OUT_FOR_DELIVERY, DELIVERED, CANCELLED
}