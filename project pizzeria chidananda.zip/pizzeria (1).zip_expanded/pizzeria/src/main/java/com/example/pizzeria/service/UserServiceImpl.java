package com.example.pizzeria.service;

import com.example.pizzeria.dto.OrderDto;
import com.example.pizzeria.dto.OrderItemDto;
import com.example.pizzeria.dto.PaymentDto;
import com.example.pizzeria.entity.*;
import com.example.pizzeria.repository.*;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {

    private final MenuItemRepository menuItemRepo;
    private final OrderRepository orderRepo;
    private final OrderItemRepository orderItemRepo;
    private final PaymentRepository paymentRepo;
    private final UserRepository userRepo;

    public UserServiceImpl(MenuItemRepository menuItemRepo,
                           OrderRepository orderRepo,
                           OrderItemRepository orderItemRepo,
                           PaymentRepository paymentRepo,
                           UserRepository userRepo) {
        this.menuItemRepo = menuItemRepo;
        this.orderRepo = orderRepo;
        this.orderItemRepo = orderItemRepo;
        this.paymentRepo = paymentRepo;
        this.userRepo = userRepo;
    }

    @Override
    public List<MenuItem> getMenu() {
        return menuItemRepo.findAll();
    }

    @Override
    public OrderDto placeOrder(OrderDto orderDto) {
        User user = userRepo.findById(orderDto.getUserId())
                .orElseThrow(() -> new RuntimeException("User not found"));

        Order order = Order.builder()
                .user(user)
                .status(OrderStatus.PLACED)
                .deliveryMode(orderDto.getDeliveryMode())
                .createdAt(LocalDateTime.now())
                .build();
        orderRepo.save(order);

        List<OrderItem> items = orderDto.getItems().stream().map(dto -> {
            MenuItem menuItem = menuItemRepo.findById(dto.getMenuItemId())
                    .orElseThrow(() -> new RuntimeException("Menu item not found"));
            OrderItem item = OrderItem.builder()
                    .order(order)
                    .menuItem(menuItem)
                    .quantity(dto.getQuantity())
                    .priceAtOrder(menuItem.getPrice())
                    .build();
            return orderItemRepo.save(item);
        }).toList();

        order.setItems(items);
        orderRepo.save(order);

        return new OrderDto(order.getId(), user.getId(),
                items.stream().map(i -> new OrderItemDto(
                        i.getMenuItem().getId(),
                        i.getQuantity(),
                        i.getPriceAtOrder()
                )).collect(Collectors.toList()),
                order.getStatus(), order.getDeliveryMode(),
                order.getCreatedAt());
    }

    @Override
    public void cancelOrder(Long orderId) {
        Order order = orderRepo.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));
        order.setStatus(OrderStatus.CANCELLED);
        orderRepo.save(order);
    }

    @Override
    public String getOrderStatus(Long orderId) {
        return orderRepo.findById(orderId)
                .map(o -> o.getStatus().name())
                .orElseThrow(() -> new RuntimeException("Order not found"));
    }

    @Override
    public void makePayment(PaymentDto paymentDto) {
        Order order = orderRepo.findById(paymentDto.getOrderId())
                .orElseThrow(() -> new RuntimeException("Order not found"));

        Payment payment = Payment.builder()
                .order(order)
                .method(paymentDto.getMethod())
                .status(paymentDto.getStatus())
                .build();

        paymentRepo.save(payment);
    }
}
